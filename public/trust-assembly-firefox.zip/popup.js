/**
 * Trust Assembly Extension — Popup Script
 * Handles: corrections display, login, follow, submit, color-coding, conflict resolution,
 * state persistence, floating window, body corrections, multi-vault, multi-assembly
 */

let currentUrl = null;
let currentUser = null;
let userAssemblies = null; // { joined: [], followed: [] }
let pendingUrlDraft = null; // Server draft for current URL (checked on popup open)
let cachedDraftsList = null; // Cached list of all user drafts

// ── Form state persistence ──
const FORM_STATE_KEY = "ta-form-draft";
let formState = {
  submitType: "correction",
  headline: "",
  replacement: "",
  reasoning: "",
  selectedAuthors: [],
  selectedOrgIds: [],
  inlineEdits: [],
  vaultItems: { correction: [], argument: [], belief: [], translation: [] },
  vaultSectionsOpen: {},
  vaultBodyOpen: false,
  inlineEditsOpen: false,
};

async function saveFormState() {
  try {
    await storageSet({ [FORM_STATE_KEY]: JSON.stringify(formState) });
  } catch (e) {}
}

async function loadFormState() {
  try {
    const result = await storageGet([FORM_STATE_KEY]);
    if (result[FORM_STATE_KEY]) {
      const saved = JSON.parse(result[FORM_STATE_KEY]);
      formState = { ...formState, ...saved };
    }
  } catch (e) {}
}

async function clearFormState() {
  formState = {
    submitType: "correction",
    headline: "",
    replacement: "",
    reasoning: "",
    selectedAuthors: [],
    selectedOrgIds: [],
    inlineEdits: [],
    vaultItems: { correction: [], argument: [], belief: [], translation: [] },
    vaultSectionsOpen: {},
    vaultBodyOpen: false,
    inlineEditsOpen: false,
  };
  try { await storageSet({ [FORM_STATE_KEY]: "" }); } catch (e) {}
}

// Debounced save on input changes
let saveTimer = null;
function debouncedSave() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(saveFormState, 300);
}

// Capture current form field values into formState
function captureFormFields() {
  const headline = document.getElementById("sub-headline");
  const replacement = document.getElementById("sub-replacement");
  const reasoning = document.getElementById("sub-reasoning");
  if (headline) formState.headline = headline.value;
  if (replacement) formState.replacement = replacement.value;
  if (reasoning) formState.reasoning = reasoning.value;

  // Capture selected org chips
  const selectedChips = document.querySelectorAll(".org-chip.selected");
  if (selectedChips.length > 0) {
    formState.selectedOrgIds = Array.from(selectedChips).map(c => c.getAttribute("data-org-id"));
  }
}

document.addEventListener("DOMContentLoaded", async () => {
  // Load saved form state first
  await loadFormState();

  // Get current tab URL
  try {
    const [tab] = typeof chrome !== "undefined" && chrome.tabs
      ? await chrome.tabs.query({ active: true, currentWindow: true })
      : await browser.tabs.query({ active: true, currentWindow: true });
    currentUrl = tab?.url;
  } catch (e) {
    try {
      const [tab] = await browser.tabs.query({ active: true, currentWindow: true });
      currentUrl = tab?.url;
    } catch (_) {}
  }

  // Check stored auth
  currentUser = await TA.getStoredUser();
  renderAuthHeader();

  // Set up tabs
  setupTabs();

  // Show login gate if not authenticated
  if (!currentUser) {
    renderLoginGate();
  } else {
    showDesignTabIfAdmin();
    // Load corrections
    loadCorrections();
    // Check for server-side draft for current URL
    if (currentUrl && currentUrl.startsWith("http")) {
      TA.getDraftByUrl(currentUrl).then(d => {
        if (d) { pendingUrlDraft = d; }
      }).catch(() => {});
      TA.getDrafts().then(d => { cachedDraftsList = d; }).catch(() => {});
    }
  }

  // Settings toggles
  setupSettings();

  // Wire up detach button
  const detachBtn = document.getElementById("btn-detach");
  if (detachBtn) {
    detachBtn.addEventListener("click", detachToWindow);
  }
});

// ── Detach to floating window ──
async function detachToWindow() {
  // Save current form state before detaching
  captureFormFields();
  await saveFormState();

  const popupUrl = typeof chrome !== "undefined" && chrome.runtime
    ? chrome.runtime.getURL("popup.html")
    : browser.runtime.getURL("popup.html");

  const createWindow = typeof chrome !== "undefined" && chrome.windows
    ? chrome.windows.create.bind(chrome.windows)
    : browser.windows.create.bind(browser.windows);

  createWindow({
    url: popupUrl + "?detached=1",
    type: "popup",
    width: 420,
    height: 700,
    top: 100,
    left: Math.max(0, screen.width - 460),
  });

  // Close the popup
  window.close();
}

// ── Auth header ──
function renderAuthHeader() {
  const el = document.getElementById("header-user");
  const nameEl = document.getElementById("header-username");
  if (currentUser) {
    nameEl.textContent = "@" + (currentUser.displayName || currentUser.username);
    el.style.display = "flex";
    document.getElementById("btn-signout").onclick = async () => {
      await TA.logout();
      currentUser = null;
      userAssemblies = null;
      renderAuthHeader();
      renderSubmitTab();
      renderAssembliesTab();
    };
  } else {
    el.style.display = "none";
  }
}

// ── Login gate (shown when not signed in) ──
function renderLoginGate() {
  const content = document.getElementById("content");
  content.innerHTML = `
    <div class="login-panel">
      <h3>Sign in to Trust Assembly</h3>
      <p style="font-size:11px; color:#5A5650; line-height:1.5; margin-bottom:10px;">Sign in to see corrections from your assemblies, submit new corrections, and manage your memberships.</p>
      <input type="text" id="login-user-gate" placeholder="Username or email" autocomplete="username">
      <input type="password" id="login-pass-gate" placeholder="Password" autocomplete="current-password">
      <button class="login-btn" id="btn-login-gate">Sign In</button>
      <div id="login-error-gate" class="login-error" style="display:none"></div>
      <div class="login-hint">Don't have an account? <a href="https://trustassembly.org/register" target="_blank" style="color:#B8963E">Register on trustassembly.org</a></div>
    </div>
  `;
  document.getElementById("btn-login-gate").addEventListener("click", doLoginGate);
  document.getElementById("login-pass-gate").addEventListener("keydown", (e) => { if (e.key === "Enter") doLoginGate(); });
}

async function doLoginGate() {
  const username = document.getElementById("login-user-gate").value.trim();
  const password = document.getElementById("login-pass-gate").value;
  const errorEl = document.getElementById("login-error-gate");
  if (!username || !password) {
    errorEl.textContent = "Username and password are required.";
    errorEl.style.display = "block";
    return;
  }
  errorEl.style.display = "none";
  const result = await TA.login(username, password);
  if (!result) {
    errorEl.textContent = "Invalid credentials. Please try again.";
    errorEl.style.display = "block";
    return;
  }
  currentUser = { username: result.username, displayName: result.displayName, id: result.id };
  userAssemblies = await TA.getMyAssemblies();
  renderAuthHeader();
  showDesignTabIfAdmin();
  loadCorrections();
}

// ── Tab switching ──
function setupTabs() {
  const buttons = document.querySelectorAll(".tab-bar button");
  buttons.forEach(btn => {
    btn.addEventListener("click", () => {
      buttons.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      const tab = btn.dataset.tab;
      document.getElementById("tab-corrections").style.display = tab === "corrections" ? "" : "none";
      document.getElementById("tab-submit").style.display = tab === "submit" ? "" : "none";
      document.getElementById("tab-assemblies").style.display = tab === "assemblies" ? "" : "none";
      document.getElementById("tab-design").style.display = tab === "design" ? "" : "none";
      if (tab === "submit") renderSubmitTab();
      else clearPreviewMessage();
      if (tab === "assemblies") renderAssembliesTab();
      if (tab === "design") renderDesignTab();
    });
  });
}

// ── Admin Design Mode ──
const ADMIN_USERNAME = "thekingofamerica";

function showDesignTabIfAdmin() {
  if (!currentUser || currentUser.username !== ADMIN_USERNAME) return;
  // Add Design tab button to tab bar
  const tabBar = document.querySelector(".tab-bar");
  if (!tabBar || tabBar.querySelector('[data-tab="design"]')) return;
  const btn = document.createElement("button");
  btn.dataset.tab = "design";
  btn.textContent = "Design";
  btn.style.color = "#B8963E";
  tabBar.appendChild(btn);
  // Re-setup tabs to include the new button
  setupTabs();
}

// ── Corrections tab ──
async function loadCorrections() {
  const content = document.getElementById("content");

  if (!currentUrl || !currentUrl.startsWith("http")) {
    content.innerHTML = `<div class="empty"><div class="empty-icon">📄</div>Navigate to a web page to see corrections, affirmations, and translations.</div>`;
    return;
  }

  // Load user assemblies for relationship badges
  if (currentUser && !userAssemblies) {
    userAssemblies = await TA.getCachedAssemblies();
    if (!userAssemblies) {
      userAssemblies = await TA.getMyAssemblies();
    }
  }

  try {
    const data = await TA.getForURL(currentUrl);
    const total = data.corrections.length + data.affirmations.length + data.translations.length;

    // Render site mute toggle if there are corrections/affirmations
    if (total > 0) {
      renderSiteMuteToggle();
    }

    if (total === 0) {
      content.innerHTML = `
        <div class="empty">
          <div class="empty-icon">✓</div>
          No corrections, affirmations, or translations found for this page.
          <br><br>
          <span style="font-size:10px; color:#B0A89C">This could mean the article hasn't been reviewed yet, or it passed review without issues.</span>
        </div>
      `;
      return;
    }

    // Apply conflict resolution to corrections
    const resolved = resolveConflicts(data.corrections);

    // Status bar
    let html = `
      <div class="status">
        <span class="status-count">${total}</span>
        ${data.corrections.length} correction${data.corrections.length !== 1 ? "s" : ""} ·
        ${data.affirmations.length} affirmation${data.affirmations.length !== 1 ? "s" : ""} ·
        ${data.translations.length} translation${data.translations.length !== 1 ? "s" : ""}
      </div>
      <div class="corrections-list">
    `;

    // Corrections (conflict-resolved)
    resolved.forEach(group => {
      html += renderCorrectionItem(group.winner);
      if (group.others.length > 0) {
        const gid = "cg-" + Math.random().toString(36).slice(2, 8);
        html += `<div class="conflict-others" onclick="document.getElementById('${gid}').classList.toggle('conflict-hidden')">See ${group.others.length} other correction${group.others.length !== 1 ? "s" : ""} for this headline</div>`;
        html += `<div id="${gid}" class="conflict-hidden">`;
        group.others.forEach(sub => { html += renderCorrectionItem(sub); });
        html += `</div>`;
      }
    });

    // Affirmations
    data.affirmations.forEach(sub => {
      const statusClass = sub.status === "consensus" ? "status-consensus" : sub.status === "approved" ? "status-approved" : "";
      html += `
        <div class="correction-item type-affirmation ${statusClass}">
          <div class="meta">🟢 Affirmation · ${escapeHtml(sub.orgName || "Assembly")}${relBadge(sub.orgId)} · ${formatStatus(sub.status)}</div>
          <div class="headline-affirmed">✓ ${escapeHtml(sub.originalHeadline)}</div>
        </div>
      `;
    });

    // Translations
    data.translations.forEach(t => {
      const types = { clarity: "Clarity", propaganda: "Anti-Propaganda", euphemism: "Euphemism", satirical: "Satirical" };
      html += `
        <div class="correction-item type-translation">
          <div class="meta">🔄 Translation · ${types[t.type] || t.type} · ${escapeHtml(t.orgName || "Assembly")}${relBadge(t.orgId)}</div>
          <div class="trans-pair">
            <span class="trans-orig">${escapeHtml(t.original)}</span>
            <span class="trans-arrow"> → </span>
            <span class="trans-result">${escapeHtml(t.translated)}</span>
          </div>
        </div>
      `;
    });

    html += "</div>";
    content.innerHTML = html;

  } catch (e) {
    content.innerHTML = `
      <div class="empty">
        <div class="empty-icon">⚠</div>
        Could not reach Trust Assembly API.
        <br><br>
        <span style="font-size:10px; color:#B0A89C">${escapeHtml(e.message)}</span>
      </div>
    `;
  }
}

// ── Design Mode Tab (Admin only) ──
const DESIGN_MOCK_DATA = {
  corrections: [{
    id: "design-c1", orgName: "The General Public", orgId: "org-1",
    originalHeadline: "MOCK: Original Headline Text Goes Here For Testing",
    replacement: "MOCK: Corrected Headline \u2014 This Is What The Extension Displays",
    reasoning: "This is mock reasoning for design testing. The original headline was misleading because it omitted key context.",
    author: "Test Author", status: "approved", trustScore: 72,
    profile: { displayName: "DesignTester" },
    evidence: [{ url: "https://example.com/evidence", explanation: "Mock evidence source" }],
    inlineEdits: [
      { original: "experts unanimously agree", replacement: "[CORRECTION: Two of five surveyed researchers expressed support]", reasoning: "Overstates consensus" },
    ],
  }],
  affirmations: [{
    id: "design-a1", orgName: "Fact Checkers United", orgId: "org-2",
    originalHeadline: "MOCK: This Headline Has Been Verified As Accurate",
    reasoning: "Methodology checks out. Sources confirmed.",
    status: "approved", trustScore: 88,
    profile: { displayName: "VerifyBot" },
  }],
  translations: [
    { id: "dt1", original: "investment", translated: "budget reallocation", type: "propaganda", orgName: "The General Public" },
    { id: "dt2", original: "right-sizing", translated: "layoffs", type: "euphemism", orgName: "The General Public" },
  ],
  meta: {},
};

let designHeadlineIndex = 0;
let designHeadlines = [];
let designReport = "";

async function renderDesignTab() {
  const content = document.getElementById("design-content");
  if (!content) return;

  content.innerHTML = `
    <h3>Design Experience</h3>
    <div class="design-info">
      Inject mock corrections, affirmations, translations, and vault artifacts into the current page to test how the extension renders on this site.
    </div>

    <button class="design-btn" id="design-inject">Inject All Mock Data Into Page</button>
    <button class="design-btn" id="design-clear" style="background:#C4573F">Clear All Injections</button>

    <div style="margin-top:12px;border-top:1px solid #DCD8D0;padding-top:12px">
      <h3>Headline Selector Navigator</h3>
      <div class="design-info">Find which DOM elements the extension detects as headlines. Use arrows to cycle through candidates and see what it finds.</div>
      <button class="design-btn-secondary" id="design-scan">Scan Page for Headlines</button>
      <div id="design-headline-nav" style="display:none">
        <div class="design-nav">
          <button id="design-prev">\u25C0</button>
          <span id="design-headline-info">0 / 0</span>
          <button id="design-next">\u25B6</button>
        </div>
        <div id="design-headline-detail" class="design-info" style="font-family:monospace;font-size:9px"></div>
      </div>
    </div>

    <div style="margin-top:12px;border-top:1px solid #DCD8D0;padding-top:12px">
      <h3>Generate Debug Report</h3>
      <div class="design-info">Generates a detailed report of the site\u2019s DOM structure, detected headlines, selectors tried, and injection results. Copy and share for debugging.</div>
      <button class="design-btn-secondary" id="design-report">Generate Report</button>
      <div id="design-report-output" style="display:none">
        <div class="design-report" id="design-report-text"></div>
        <button class="design-btn-secondary" id="design-copy-report" style="margin-top:4px">Copy Report to Clipboard</button>
      </div>
    </div>
  `;

  // Wire up buttons
  document.getElementById("design-inject").addEventListener("click", designInjectMockData);
  document.getElementById("design-clear").addEventListener("click", designClearInjections);
  document.getElementById("design-scan").addEventListener("click", designScanHeadlines);
  document.getElementById("design-report").addEventListener("click", designGenerateReport);
}

async function sendDesignMessage(msg) {
  try {
    const tabs = typeof chrome !== "undefined" && chrome.tabs
      ? await chrome.tabs.query({ active: true, currentWindow: true })
      : await browser.tabs.query({ active: true, currentWindow: true });
    const tab = tabs[0];
    if (tab && tab.id) {
      return new Promise((resolve) => {
        try {
          chrome.tabs.sendMessage(tab.id, msg, resolve);
        } catch (e) {
          try { browser.tabs.sendMessage(tab.id, msg, resolve); } catch (_) { resolve(null); }
        }
      });
    }
  } catch (e) {}
  return null;
}

async function designInjectMockData() {
  const btn = document.getElementById("design-inject");
  btn.textContent = "Injecting...";
  btn.classList.add("active");
  await sendDesignMessage({ type: "TA_DESIGN_INJECT", data: DESIGN_MOCK_DATA });
  btn.textContent = "Mock Data Injected";
  setTimeout(() => { btn.textContent = "Inject All Mock Data Into Page"; btn.classList.remove("active"); }, 2000);
}

async function designClearInjections() {
  await sendDesignMessage({ type: "TA_DESIGN_CLEAR" });
  const btn = document.getElementById("design-clear");
  btn.textContent = "Cleared!";
  setTimeout(() => { btn.textContent = "Clear All Injections"; }, 1500);
}

async function designScanHeadlines() {
  const result = await sendDesignMessage({ type: "TA_DESIGN_SCAN_HEADLINES" });
  if (!result || !result.headlines) {
    document.getElementById("design-headline-nav").style.display = "none";
    return;
  }
  designHeadlines = result.headlines;
  designHeadlineIndex = 0;
  document.getElementById("design-headline-nav").style.display = "";
  updateDesignHeadlineNav();
}

function updateDesignHeadlineNav() {
  const info = document.getElementById("design-headline-info");
  const detail = document.getElementById("design-headline-detail");
  if (designHeadlines.length === 0) {
    info.textContent = "No headlines found";
    detail.textContent = "";
    return;
  }
  const h = designHeadlines[designHeadlineIndex];
  info.textContent = `${designHeadlineIndex + 1} / ${designHeadlines.length}`;
  detail.innerHTML = `<strong>Tag:</strong> ${escapeHtml(h.tag)}<br><strong>Class:</strong> ${escapeHtml(h.className || "(none)")}<br><strong>Text:</strong> ${escapeHtml(h.text.slice(0, 120))}${h.text.length > 120 ? "..." : ""}<br><strong>Selector:</strong> ${escapeHtml(h.selector)}<br><strong>Phase:</strong> ${h.phase}`;

  // Highlight on page
  sendDesignMessage({ type: "TA_DESIGN_HIGHLIGHT", index: designHeadlineIndex });

  // Wire arrows
  document.getElementById("design-prev").onclick = () => {
    designHeadlineIndex = (designHeadlineIndex - 1 + designHeadlines.length) % designHeadlines.length;
    updateDesignHeadlineNav();
  };
  document.getElementById("design-next").onclick = () => {
    designHeadlineIndex = (designHeadlineIndex + 1) % designHeadlines.length;
    updateDesignHeadlineNav();
  };
}

async function designGenerateReport() {
  const btn = document.getElementById("design-report");
  btn.textContent = "Generating...";
  const result = await sendDesignMessage({ type: "TA_DESIGN_REPORT" });
  btn.textContent = "Generate Report";
  const output = document.getElementById("design-report-output");
  const text = document.getElementById("design-report-text");
  if (!result || !result.report) {
    text.textContent = "Could not generate report. Is the content script loaded on this page?";
  } else {
    designReport = result.report;
    text.textContent = result.report;
  }
  output.style.display = "";
  document.getElementById("design-copy-report").onclick = () => {
    navigator.clipboard.writeText(designReport);
    document.getElementById("design-copy-report").textContent = "Copied!";
    setTimeout(() => { document.getElementById("design-copy-report").textContent = "Copy Report to Clipboard"; }, 1500);
  };
}

// ── Per-site mute toggle ──
const MUTED_KEY = "ta-muted-sites";

function getSiteDomain(url) {
  try { return new URL(url).hostname.replace(/^www\./, ""); } catch (e) { return ""; }
}

async function isSiteMutedPopup() {
  const domain = getSiteDomain(currentUrl);
  if (!domain) return false;
  const result = await storageGet([MUTED_KEY]);
  try {
    const muted = result[MUTED_KEY] ? JSON.parse(result[MUTED_KEY]) : {};
    return !!muted[domain];
  } catch (e) { return false; }
}

async function setSiteMutedPopup(mute) {
  const domain = getSiteDomain(currentUrl);
  if (!domain) return;
  const result = await storageGet([MUTED_KEY]);
  const sites = result[MUTED_KEY] ? JSON.parse(result[MUTED_KEY]) : {};
  if (mute) {
    sites[domain] = true;
  } else {
    delete sites[domain];
  }
  await storageSet({ [MUTED_KEY]: JSON.stringify(sites) });

  // Notify content script
  try {
    const tabs = typeof chrome !== "undefined" && chrome.tabs
      ? await chrome.tabs.query({ active: true, currentWindow: true })
      : await browser.tabs.query({ active: true, currentWindow: true });
    const tab = tabs[0];
    if (tab && tab.id) {
      const msg = { type: "TA_SITE_MUTE_CHANGED", domain, muted: mute };
      try { chrome.tabs.sendMessage(tab.id, msg); } catch (e) {
        try { browser.tabs.sendMessage(tab.id, msg); } catch (_) {}
      }
    }
  } catch (e) {}
}

async function renderSiteMuteToggle() {
  const container = document.getElementById("site-mute-container");
  if (!container || !currentUrl) return;

  const domain = getSiteDomain(currentUrl);
  if (!domain) return;

  const muted = await isSiteMutedPopup();

  container.innerHTML = `
    <div class="site-mute-bar">
      <span>Corrections on <strong>${escapeHtml(domain)}</strong></span>
      <div class="mute-switch${muted ? " muted" : ""}" id="popup-mute-switch">
        <span class="mute-knob"></span>
      </div>
    </div>
  `;

  document.getElementById("popup-mute-switch").addEventListener("click", async () => {
    const sw = document.getElementById("popup-mute-switch");
    const currentlyMuted = sw.classList.contains("muted");
    const newMuted = !currentlyMuted;

    // Update visual immediately
    sw.classList.toggle("muted", newMuted);

    // Persist and notify
    await setSiteMutedPopup(newMuted);
  });
}

function renderCorrectionItem(sub) {
  const statusClass = sub.status === "consensus" ? "status-consensus" : sub.status === "approved" ? "status-approved" : "";
  return `
    <div class="correction-item type-correction ${statusClass}">
      <div class="meta">🔴 Correction · ${escapeHtml(sub.orgName || "Assembly")}${relBadge(sub.orgId)} · ${formatStatus(sub.status)}</div>
      <div class="headline-new">${escapeHtml(sub.replacement)}<div class="headline-original-tooltip"><div class="tooltip-label">Original Headline</div>${escapeHtml(sub.originalHeadline)}</div></div>
    </div>
  `;
}

// ── Conflict resolution ──
function resolveConflicts(corrections) {
  const groups = {};
  corrections.forEach(sub => {
    const key = (sub.originalHeadline || "").toLowerCase().trim();
    if (!groups[key]) groups[key] = [];
    groups[key].push(sub);
  });

  return Object.values(groups).map(items => {
    items.sort((a, b) => {
      const sa = a.trustScore ?? -1;
      const sb = b.trustScore ?? -1;
      if (sb !== sa) return sb - sa;
      return (a.orgName || "").localeCompare(b.orgName || "");
    });
    return { winner: items[0], others: items.slice(1) };
  });
}

// ── Relationship badge ──
function relBadge(orgId) {
  if (!userAssemblies || !orgId) return "";
  if (userAssemblies.joined && userAssemblies.joined.some(o => o.id === orgId)) {
    return ' <span class="rel-badge joined">Joined</span>';
  }
  if (userAssemblies.followed && userAssemblies.followed.some(o => o.id === orgId)) {
    return ' <span class="rel-badge followed">Followed</span>';
  }
  return "";
}

// ── Submit tab ──
let detectedAuthors = []; // auto-detected from page
let detectedContentType = "article"; // auto-detected from page

// Platform-adaptive labels for the submit form
function getFormLabels(contentType) {
  switch (contentType) {
    case "video": return { headline: "Video Title", replacement: "Corrected Title", author: "Channel / Creator", url: "Video URL" };
    case "shortform": return { headline: "Original Post Text", replacement: "Corrected Post", author: "Account", url: "Post URL" };
    case "audio": return { headline: "Episode Title", replacement: "Corrected Title", author: "Host / Speaker", url: "Episode URL" };
    case "product": return { headline: "Product Name / Title", replacement: "Corrected Claim", author: "Brand / Seller", url: "Product URL" };
    default: return { headline: "Original Headline", replacement: "Corrected Headline", author: "Author(s)", url: "Article URL" };
  }
}

async function renderSubmitTab() {
  const gate = document.getElementById("submit-gate");
  if (!currentUser) {
    gate.innerHTML = `
      <div class="login-panel">
        <h3>Sign in to submit</h3>
        <p style="font-size:11px; color:#5A5650; line-height:1.5; margin-bottom:10px;">Sign in to submit corrections, affirmations, and vault artifacts for your assemblies.</p>
        <input type="text" id="login-user" placeholder="Username or email" autocomplete="username">
        <input type="password" id="login-pass" placeholder="Password" autocomplete="current-password">
        <button class="login-btn" id="btn-login">Sign In</button>
        <div id="login-error" class="login-error" style="display:none"></div>
        <div class="login-hint">Don't have an account? <a href="https://trustassembly.org/register" target="_blank" style="color:#B8963E">Register on trustassembly.org</a></div>
      </div>
    `;
    document.getElementById("btn-login").addEventListener("click", doLogin);
    document.getElementById("login-pass").addEventListener("keydown", (e) => { if (e.key === "Enter") doLogin(); });
    return;
  }

  // Logged in — show submit form
  const joinedOrgs = userAssemblies?.joined || [];
  if (joinedOrgs.length === 0) {
    gate.innerHTML = `
      <div class="submit-panel">
        <div class="empty">
          <div class="empty-icon">⚖</div>
          You must be a member of at least one assembly to submit.
          <br><br>
          <a href="https://trustassembly.org/orgs" target="_blank" style="color:#B8963E">Join an assembly on trustassembly.org</a>
        </div>
      </div>
    `;
    return;
  }

  const isAffirm = formState.submitType === "affirmation";

  // Multi-assembly clickable chips (compact grid)
  const orgCheckboxesHtml = `<div style="display:flex;flex-wrap:wrap;gap:4px">` + joinedOrgs.map(o => {
    const selected = formState.selectedOrgIds.length > 0
      ? formState.selectedOrgIds.includes(o.id)
      : joinedOrgs.length === 1;
    return `<span class="org-chip${selected ? " selected" : ""}" data-org-id="${escapeHtml(o.id)}" style="padding:4px 10px;font-size:10px;cursor:pointer;border:1px solid ${selected ? "#d4a843" : "#2a2518"};background:${selected ? "rgba(212,168,67,0.13)" : "transparent"};color:${selected ? "#d4a843" : "#8a8278"};font-weight:${selected ? "700" : "400"};font-family:monospace;letter-spacing:0.5px">${escapeHtml(o.name)}</span>`;
  }).join("") + `</div>`;

  // Author tags HTML
  let authorTagsHtml = formState.selectedAuthors.map((a, i) =>
    `<span class="author-tag">${escapeHtml(a)}<span class="remove" data-author-idx="${i}">&times;</span></span>`
  ).join("");

  // Inline edits (body corrections) HTML
  let inlineEditsHtml = formState.inlineEdits.map((edit, i) => `
    <div class="inline-edit-entry" data-edit-idx="${i}">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
        <span style="font-size:10px;font-weight:600;color:#1B2A4A">Body Edit #${i + 1}</span>
        <span class="remove-edit" data-edit-remove="${i}" style="cursor:pointer;color:#C4573F;font-size:12px">&times; Remove</span>
      </div>
      <input type="text" class="edit-original" data-edit-field="original" data-edit-idx="${i}" placeholder="Original text from article" value="${escapeHtml(edit.original || "")}">
      <input type="text" class="edit-replacement" data-edit-field="replacement" data-edit-idx="${i}" placeholder="Corrected text" value="${escapeHtml(edit.replacement || "")}">
      <input type="text" class="edit-reasoning" data-edit-field="reasoning" data-edit-idx="${i}" placeholder="Why this change? (optional)" value="${escapeHtml(edit.reasoning || "")}">
    </div>
  `).join("");

  // Build vault items HTML for each type supporting multiples
  function buildVaultItemsHtml(type, items, config) {
    let html = items.map((item, i) => {
      let fieldsHtml = "";
      config.fields.forEach(f => {
        if (f.type === "textarea") {
          fieldsHtml += `<textarea class="vault-item-field" data-vault-type="${type}" data-vault-idx="${i}" data-vault-field="${f.key}" placeholder="${f.placeholder}">${escapeHtml(item[f.key] || "")}</textarea>`;
        } else if (f.type === "select") {
          const opts = f.options.map(o => `<option value="${o.value}" ${item[f.key] === o.value ? "selected" : ""}>${o.label}</option>`).join("");
          fieldsHtml += `<select class="vault-item-field" data-vault-type="${type}" data-vault-idx="${i}" data-vault-field="${f.key}">${opts}</select>`;
        } else {
          fieldsHtml += `<input type="text" class="vault-item-field" data-vault-type="${type}" data-vault-idx="${i}" data-vault-field="${f.key}" placeholder="${f.placeholder}" value="${escapeHtml(item[f.key] || "")}">`;
        }
      });
      return `
        <div class="vault-multi-entry" style="margin-bottom:6px;padding:6px;background:#FDFBF5;border:1px solid #EBE8E2;border-radius:3px">
          <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:4px">
            <span style="font-size:9px;color:#7A7570">#${i + 1}</span>
            <span class="remove-vault-item" data-vault-type="${type}" data-vault-remove="${i}" style="cursor:pointer;color:#C4573F;font-size:11px">&times;</span>
          </div>
          ${fieldsHtml}
        </div>
      `;
    }).join("");
    html += `<button class="add-vault-item-btn" data-vault-add="${type}" style="font-size:10px;color:#B8963E;background:none;border:1px dashed #DCD8D0;padding:4px 8px;border-radius:3px;cursor:pointer;width:100%;margin-top:4px">+ Add another ${config.label}</button>`;
    return html;
  }

  const vaultConfigs = {
    correction: {
      label: "standing correction",
      fields: [
        { key: "assertion", type: "text", placeholder: "Factual assertion (e.g. 'The recall was software-only')" },
        { key: "evidence", type: "text", placeholder: "Supporting evidence or source URL" },
      ]
    },
    argument: {
      label: "argument",
      fields: [
        { key: "content", type: "textarea", placeholder: "The argument (e.g. 'Correlation does not imply causation…')" },
      ]
    },
    belief: {
      label: "belief",
      fields: [
        { key: "content", type: "textarea", placeholder: "The belief (e.g. 'Free speech includes speech we disagree with')" },
      ]
    },
    translation: {
      label: "translation",
      fields: [
        { key: "original", type: "text", placeholder: "Original term or phrase" },
        { key: "translated", type: "text", placeholder: "Plain-language replacement" },
        { key: "translationType", type: "select", options: [
          { value: "clarity", label: "Clarity" },
          { value: "propaganda", label: "Anti-Propaganda" },
          { value: "euphemism", label: "Euphemism" },
          { value: "satirical", label: "Satirical" },
        ]},
      ]
    },
  };

  gate.innerHTML = `
    <div class="submit-panel">
      <h3>Submit to Trust Assembly</h3>

      <!-- Submission type toggle -->
      <div class="type-toggle">
        <button id="btn-type-correction" class="${!isAffirm ? 'active-correction' : ''}">
          <div>Correction</div>
          <div class="type-desc">Headline is misleading</div>
        </button>
        <button id="btn-type-affirmation" class="${isAffirm ? 'active-affirmation' : ''}">
          <div>Affirmation</div>
          <div class="type-desc">Headline is accurate</div>
        </button>
      </div>

      ${isAffirm ? '<div class="affirm-banner">You are affirming this headline is <strong>accurate</strong>. The original headline will be wrapped in green to signal accuracy. No replacement needed.</div>' : ''}

      <label>Submit to Assembly(s) ${joinedOrgs.length > 1 ? '<span style="font-size:9px;color:#B0A89C;font-weight:400">— click to select</span>' : ''}</label>
      <div id="org-checkboxes">${orgCheckboxesHtml}</div>

      <label>${getFormLabels(detectedContentType).url}</label>
      <input type="text" id="sub-url" value="${escapeHtml(currentUrl || "")}" readonly>

      <label>${getFormLabels(detectedContentType).headline}</label>
      <input type="text" id="sub-headline" placeholder="Detecting…" value="${escapeHtml(formState.headline || "")}">

      ${!isAffirm ? `
        <label>${getFormLabels(detectedContentType).replacement}</label>
        <input type="text" id="sub-replacement" placeholder="Your proposed correction" value="${escapeHtml(formState.replacement || "")}">
      ` : ''}

      <label>${getFormLabels(detectedContentType).author} <span style="font-size:9px;color:#B0A89C;font-weight:400">— auto-detected from page</span></label>
      <div class="author-tags" id="author-tags">${authorTagsHtml}</div>
      ${detectedAuthors.length > 0 && formState.selectedAuthors.length < 10 ? `
        <select id="author-select" style="margin-bottom:4px">
          <option value="">Add an author…</option>
          ${detectedAuthors.filter(a => !formState.selectedAuthors.includes(a)).map(a => `<option value="${escapeHtml(a)}">${escapeHtml(a)}</option>`).join("")}
          <option value="__custom__">Enter manually…</option>
        </select>
      ` : formState.selectedAuthors.length < 10 ? `
        <input type="text" id="author-manual" placeholder="Type author name and press Enter" style="margin-bottom:4px">
      ` : ''}
      <div class="author-hint">${formState.selectedAuthors.length}/10 authors max</div>

      <label>Reasoning</label>
      <textarea id="sub-reasoning" placeholder="${isAffirm ? 'Why is this headline accurate?' : 'Why is this correction needed?'}">${escapeHtml(formState.reasoning || "")}</textarea>

      <!-- Body Corrections (inline edits) -->
      <div class="vault-section">
        <div class="vault-section-title" id="inline-edits-toggle">${formState.inlineEditsOpen ? '−' : '+'} Body Corrections (optional)</div>
        <div id="inline-edits-body" style="display:${formState.inlineEditsOpen ? 'block' : 'none'}">
          <div style="font-size:10px; color:#7A7570; margin-bottom:8px; line-height:1.4;">Correct specific text within the article body. Select the original text and provide the corrected version.</div>
          <div id="inline-edits-list">${inlineEditsHtml}</div>
          ${formState.inlineEdits.length === 0 ? `<button id="add-first-edit" class="add-vault-item-btn" style="font-size:10px;color:#B8963E;background:none;border:1px dashed #DCD8D0;padding:4px 8px;border-radius:3px;cursor:pointer;width:100%">+ Add a body correction</button>` : ''}
        </div>
      </div>

      <!-- Vault Artifacts (optional) -->
      <div class="vault-section">
        <div class="vault-section-title" id="vault-toggle">${formState.vaultBodyOpen ? '−' : '+'} Vault Artifacts (optional)</div>
        <div id="vault-body" style="display:${formState.vaultBodyOpen ? 'block' : 'none'}">
          <div style="font-size:10px; color:#7A7570; margin-bottom:8px; line-height:1.4;">Optionally add entries to your assembly's vaults alongside this submission. You can add multiple of each type.</div>

          <!-- Standing Correction -->
          <div class="vault-type-row vault-color-correction">
            <div class="vault-type-header" data-vault="correction">
              <span class="vault-type-label">Standing Corrections</span>
              <span class="vault-type-toggle">${formState.vaultSectionsOpen.correction ? '−' : '+'}</span>
            </div>
            <div class="vault-type-body" style="display:${formState.vaultSectionsOpen.correction ? 'block' : 'none'}" data-vault-body="correction">
              <div class="vault-type-desc">Reusable verified facts for your assembly's Fact Vault.</div>
              ${buildVaultItemsHtml("correction", formState.vaultItems.correction, vaultConfigs.correction)}
            </div>
          </div>

          <!-- Argument -->
          <div class="vault-type-row vault-color-argument">
            <div class="vault-type-header" data-vault="argument">
              <span class="vault-type-label">Arguments</span>
              <span class="vault-type-toggle">${formState.vaultSectionsOpen.argument ? '−' : '+'}</span>
            </div>
            <div class="vault-type-body" style="display:${formState.vaultSectionsOpen.argument ? 'block' : 'none'}" data-vault-body="argument">
              <div class="vault-type-desc">Fundamental arguments for reuse across articles.</div>
              ${buildVaultItemsHtml("argument", formState.vaultItems.argument, vaultConfigs.argument)}
            </div>
          </div>

          <!-- Belief -->
          <div class="vault-type-row vault-color-belief">
            <div class="vault-type-header" data-vault="belief">
              <span class="vault-type-label">Foundational Beliefs</span>
              <span class="vault-type-toggle">${formState.vaultSectionsOpen.belief ? '−' : '+'}</span>
            </div>
            <div class="vault-type-body" style="display:${formState.vaultSectionsOpen.belief ? 'block' : 'none'}" data-vault-body="belief">
              <div class="vault-type-desc">Core axioms or starting premises, not claims of fact.</div>
              ${buildVaultItemsHtml("belief", formState.vaultItems.belief, vaultConfigs.belief)}
            </div>
          </div>

          <!-- Translation -->
          <div class="vault-type-row vault-color-translation">
            <div class="vault-type-header" data-vault="translation">
              <span class="vault-type-label">Translations</span>
              <span class="vault-type-toggle">${formState.vaultSectionsOpen.translation ? '−' : '+'}</span>
            </div>
            <div class="vault-type-body" style="display:${formState.vaultSectionsOpen.translation ? 'block' : 'none'}" data-vault-body="translation">
              <div class="vault-type-desc">Plain-language replacements for jargon, spin, or propaganda.</div>
              ${buildVaultItemsHtml("translation", formState.vaultItems.translation, vaultConfigs.translation)}
            </div>
          </div>
        </div>
      </div>

      <div style="display:flex;gap:6px;margin-top:10px">
        <button class="submit-btn" id="btn-submit" style="flex:1; background:${isAffirm ? '#1B5E3F' : '#C4573F'}">
          Submit ${isAffirm ? 'Affirmation' : 'Correction'}
        </button>
        <button class="submit-btn" id="btn-save-draft" style="flex:0 0 auto; background:#B8963E; padding:8px 14px; font-size:11px">
          Save Draft
        </button>
      </div>
      <div id="draft-msg" class="submit-msg" style="display:none"></div>
      <div id="submit-msg" class="submit-msg" style="display:none"></div>

      ${pendingUrlDraft ? `
      <div id="draft-banner" style="margin-top:8px;padding:8px 10px;background:#FFFBEB;border:1px solid #B8963E;border-radius:4px;display:flex;justify-content:space-between;align-items:center">
        <span style="font-size:11px;color:#7A7570">Saved draft found for this page</span>
        <div style="display:flex;gap:6px">
          <button id="btn-load-url-draft" style="font-size:10px;color:#1B5E3F;background:none;border:1px solid #1B5E3F;padding:3px 8px;border-radius:3px;cursor:pointer">Load</button>
          <button id="btn-dismiss-draft" style="font-size:10px;color:#7A7570;background:none;border:none;cursor:pointer">Dismiss</button>
        </div>
      </div>
      ` : ''}

      ${cachedDraftsList && cachedDraftsList.length > 0 ? `
      <div style="margin-top:8px;border-top:1px solid #EBE8E2;padding-top:8px">
        <div style="font-size:10px;font-weight:600;color:#B8963E;text-transform:uppercase;letter-spacing:0.05em;margin-bottom:4px">Saved Drafts (${cachedDraftsList.length})</div>
        ${cachedDraftsList.slice(0, 5).map(d => {
          let domain = "";
          try { domain = new URL(d.url).hostname.replace(/^www\\./, ""); } catch {}
          return `
          <div class="draft-list-item" style="display:flex;justify-content:space-between;align-items:center;padding:4px 6px;margin-bottom:3px;background:#FDFBF5;border:1px solid #EBE8E2;border-radius:3px">
            <div style="flex:1;min-width:0;overflow:hidden">
              <div style="font-size:11px;color:#1B2A4A;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${escapeHtml(d.title || "(no headline)")}</div>
              <div style="font-size:9px;color:#7A7570">${escapeHtml(domain)}</div>
            </div>
            <div style="display:flex;gap:4px;flex-shrink:0;margin-left:6px">
              <button class="draft-load-btn" data-draft-id="${d.id}" style="font-size:9px;color:#1B5E3F;background:none;border:1px solid #1B5E3F;padding:2px 6px;border-radius:3px;cursor:pointer">Load</button>
              <button class="draft-delete-btn" data-draft-id="${d.id}" style="font-size:9px;color:#C4573F;background:none;border:none;cursor:pointer">Del</button>
            </div>
          </div>`;
        }).join("")}
        ${cachedDraftsList.length > 5 ? `<div style="font-size:9px;color:#7A7570">+ ${cachedDraftsList.length - 5} more</div>` : ''}
      </div>
      ` : ''}
    </div>
  `;

  // ── Wire up event listeners ──

  // Type toggle (save on change, but don't re-render to avoid losing unsaved field values)
  document.getElementById("btn-type-correction").addEventListener("click", () => {
    captureFormFields();
    formState.submitType = "correction";
    debouncedSave();
    renderSubmitTab();
  });
  document.getElementById("btn-type-affirmation").addEventListener("click", () => {
    captureFormFields();
    formState.submitType = "affirmation";
    debouncedSave();
    renderSubmitTab();
  });

  // Form field persistence on input
  ["sub-headline", "sub-replacement", "sub-reasoning"].forEach(id => {
    const el = document.getElementById(id);
    if (el) {
      el.addEventListener("input", () => {
        if (id === "sub-headline") formState.headline = el.value;
        else if (id === "sub-replacement") formState.replacement = el.value;
        else if (id === "sub-reasoning") formState.reasoning = el.value;
        debouncedSave();
      });
    }
  });

  // Org chip click toggle
  document.querySelectorAll(".org-chip").forEach(chip => {
    chip.addEventListener("click", () => {
      const orgId = chip.getAttribute("data-org-id");
      const idx = formState.selectedOrgIds.indexOf(orgId);
      if (idx >= 0) { formState.selectedOrgIds.splice(idx, 1); chip.classList.remove("selected"); chip.style.border = "1px solid #2a2518"; chip.style.background = "transparent"; chip.style.color = "#8a8278"; chip.style.fontWeight = "400"; }
      else { formState.selectedOrgIds.push(orgId); chip.classList.add("selected"); chip.style.border = "1px solid #d4a843"; chip.style.background = "rgba(212,168,67,0.13)"; chip.style.color = "#d4a843"; chip.style.fontWeight = "700"; }
      debouncedSave();
    });
  });

  // Inline edits toggle
  document.getElementById("inline-edits-toggle").addEventListener("click", () => {
    const body = document.getElementById("inline-edits-body");
    formState.inlineEditsOpen = body.style.display === "none";
    body.style.display = formState.inlineEditsOpen ? "block" : "none";
    document.getElementById("inline-edits-toggle").textContent = (formState.inlineEditsOpen ? "− " : "+ ") + "Body Corrections (optional)";
    debouncedSave();
  });

  // Add first inline edit
  const addFirstEdit = document.getElementById("add-first-edit");
  if (addFirstEdit) {
    addFirstEdit.addEventListener("click", () => {
      formState.inlineEdits.push({ original: "", replacement: "", reasoning: "" });
      debouncedSave();
      renderSubmitTab();
    });
  }

  // Inline edit field changes
  document.querySelectorAll(".edit-original, .edit-replacement, .edit-reasoning").forEach(el => {
    el.addEventListener("input", () => {
      const idx = parseInt(el.dataset.editIdx);
      const field = el.dataset.editField;
      if (formState.inlineEdits[idx]) {
        formState.inlineEdits[idx][field] = el.value;
        debouncedSave();
        // Live preview inline edits on the page
        debouncedInlinePreview();
      }
    });
  });

  // Remove inline edit
  document.querySelectorAll("[data-edit-remove]").forEach(btn => {
    btn.addEventListener("click", () => {
      const idx = parseInt(btn.dataset.editRemove);
      formState.inlineEdits.splice(idx, 1);
      debouncedSave();
      renderSubmitTab();
    });
  });

  // Vault body toggle
  document.getElementById("vault-toggle").addEventListener("click", () => {
    const body = document.getElementById("vault-body");
    formState.vaultBodyOpen = body.style.display === "none";
    body.style.display = formState.vaultBodyOpen ? "block" : "none";
    document.getElementById("vault-toggle").textContent = (formState.vaultBodyOpen ? "− " : "+ ") + "Vault Artifacts (optional)";
    debouncedSave();
  });

  // Individual vault type toggles
  document.querySelectorAll("[data-vault]").forEach(header => {
    header.addEventListener("click", () => {
      const key = header.dataset.vault;
      const body = document.querySelector(`[data-vault-body="${key}"]`);
      const icon = header.querySelector(".vault-type-toggle");
      formState.vaultSectionsOpen[key] = body.style.display === "none";
      body.style.display = formState.vaultSectionsOpen[key] ? "block" : "none";
      icon.textContent = formState.vaultSectionsOpen[key] ? "−" : "+";
      debouncedSave();
    });
  });

  // Vault item field changes
  document.querySelectorAll(".vault-item-field").forEach(el => {
    el.addEventListener("input", () => {
      const type = el.dataset.vaultType;
      const idx = parseInt(el.dataset.vaultIdx);
      const field = el.dataset.vaultField;
      if (formState.vaultItems[type] && formState.vaultItems[type][idx]) {
        formState.vaultItems[type][idx][field] = el.value;
        debouncedSave();
      }
    });
    // Also capture select changes
    el.addEventListener("change", () => {
      const type = el.dataset.vaultType;
      const idx = parseInt(el.dataset.vaultIdx);
      const field = el.dataset.vaultField;
      if (formState.vaultItems[type] && formState.vaultItems[type][idx]) {
        formState.vaultItems[type][idx][field] = el.value;
        debouncedSave();
      }
    });
  });

  // Add vault item buttons
  document.querySelectorAll("[data-vault-add]").forEach(btn => {
    btn.addEventListener("click", () => {
      captureFormFields();
      const type = btn.dataset.vaultAdd;
      const defaults = { correction: { assertion: "", evidence: "" }, argument: { content: "" }, belief: { content: "" }, translation: { original: "", translated: "", translationType: "clarity" } };
      formState.vaultItems[type].push({ ...(defaults[type] || {}) });
      debouncedSave();
      renderSubmitTab();
    });
  });

  // Remove vault item buttons
  document.querySelectorAll("[data-vault-remove]").forEach(btn => {
    btn.addEventListener("click", () => {
      captureFormFields();
      const type = btn.dataset.vaultType;
      const idx = parseInt(btn.dataset.vaultRemove);
      formState.vaultItems[type].splice(idx, 1);
      debouncedSave();
      renderSubmitTab();
    });
  });

  // Author removal
  document.querySelectorAll("[data-author-idx]").forEach(btn => {
    btn.addEventListener("click", () => {
      const idx = parseInt(btn.dataset.authorIdx);
      formState.selectedAuthors.splice(idx, 1);
      debouncedSave();
      renderSubmitTab();
    });
  });

  // Author selection
  const authorSelect = document.getElementById("author-select");
  if (authorSelect) {
    authorSelect.addEventListener("change", () => {
      const val = authorSelect.value;
      if (val === "__custom__") {
        const parent = authorSelect.parentNode;
        const input = document.createElement("input");
        input.type = "text";
        input.id = "author-manual-inline";
        input.placeholder = "Type author name and press Enter";
        input.style.cssText = "display:block;width:100%;padding:6px 8px;margin-bottom:4px;border:1px solid #DCD8D0;border-radius:3px;font-size:11px;background:#fff;";
        parent.insertBefore(input, authorSelect);
        authorSelect.style.display = "none";
        input.focus();
        input.addEventListener("keydown", (e) => {
          if (e.key === "Enter") {
            e.preventDefault();
            const name = input.value.trim();
            if (name && formState.selectedAuthors.length < 10 && !formState.selectedAuthors.includes(name)) {
              formState.selectedAuthors.push(name);
              debouncedSave();
              renderSubmitTab();
            }
          }
        });
      } else if (val && formState.selectedAuthors.length < 10 && !formState.selectedAuthors.includes(val)) {
        formState.selectedAuthors.push(val);
        debouncedSave();
        renderSubmitTab();
      }
    });
  }

  // Manual author input
  const authorManual = document.getElementById("author-manual");
  if (authorManual) {
    authorManual.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        const name = authorManual.value.trim();
        if (name && formState.selectedAuthors.length < 10 && !formState.selectedAuthors.includes(name)) {
          formState.selectedAuthors.push(name);
          debouncedSave();
          renderSubmitTab();
        }
      }
    });
  }

  // Submit button
  document.getElementById("btn-submit").addEventListener("click", doSubmit);

  // Save Draft button
  const btnSaveDraft = document.getElementById("btn-save-draft");
  if (btnSaveDraft) {
    btnSaveDraft.addEventListener("click", async () => {
      captureFormFields();
      const url = document.getElementById("sub-url")?.value?.trim();
      if (!url) {
        const draftMsgEl = document.getElementById("draft-msg");
        if (draftMsgEl) { draftMsgEl.textContent = "Enter a URL first."; draftMsgEl.className = "submit-msg error"; draftMsgEl.style.display = "block"; }
        return;
      }
      btnSaveDraft.disabled = true;
      btnSaveDraft.textContent = "Saving...";
      const result = await TA.saveDraft(url, formState.headline || null, formState);
      const draftMsgEl = document.getElementById("draft-msg");
      if (result.error) {
        if (draftMsgEl) { draftMsgEl.textContent = result.error; draftMsgEl.className = "submit-msg error"; draftMsgEl.style.display = "block"; }
      } else {
        if (draftMsgEl) { draftMsgEl.textContent = "Draft saved!"; draftMsgEl.className = "submit-msg success"; draftMsgEl.style.display = "block"; }
        // Refresh drafts list
        cachedDraftsList = await TA.getDrafts();
      }
      btnSaveDraft.disabled = false;
      btnSaveDraft.textContent = "Save Draft";
      setTimeout(() => { if (draftMsgEl) draftMsgEl.style.display = "none"; }, 3000);
    });
  }

  // Load URL draft banner
  const btnLoadUrlDraft = document.getElementById("btn-load-url-draft");
  if (btnLoadUrlDraft && pendingUrlDraft) {
    btnLoadUrlDraft.addEventListener("click", () => {
      if (pendingUrlDraft.draftData) {
        formState = { ...formState, ...pendingUrlDraft.draftData };
        pendingUrlDraft = null;
        renderSubmitTab();
      }
    });
  }
  const btnDismissDraft = document.getElementById("btn-dismiss-draft");
  if (btnDismissDraft) {
    btnDismissDraft.addEventListener("click", () => {
      pendingUrlDraft = null;
      const banner = document.getElementById("draft-banner");
      if (banner) banner.style.display = "none";
    });
  }

  // Draft list load/delete buttons
  document.querySelectorAll(".draft-load-btn").forEach(btn => {
    btn.addEventListener("click", async () => {
      const id = btn.dataset.draftId;
      const draft = await TA.getDraft(id);
      if (draft && draft.draftData) {
        formState = { ...formState, ...draft.draftData };
        renderSubmitTab();
      }
    });
  });
  document.querySelectorAll(".draft-delete-btn").forEach(btn => {
    btn.addEventListener("click", async () => {
      const id = btn.dataset.draftId;
      await TA.deleteDraft(id);
      cachedDraftsList = await TA.getDrafts();
      renderSubmitTab();
    });
  });

  // Live preview for replacement headline
  const replacementInput = document.getElementById("sub-replacement");
  if (replacementInput) {
    let previewTimer = null;
    replacementInput.addEventListener("input", () => {
      clearTimeout(previewTimer);
      previewTimer = setTimeout(() => {
        sendPreviewMessage(replacementInput.value);
      }, 100);
    });
  }

  // Auto-detect headline and authors from current page
  try {
    const tabs = typeof chrome !== "undefined" && chrome.tabs
      ? await chrome.tabs.query({ active: true, currentWindow: true })
      : await browser.tabs.query({ active: true, currentWindow: true });
    const tab = tabs[0];
    if (tab && tab.id) {
      const sendMsg = (typeof chrome !== "undefined" && chrome.tabs)
        ? chrome.tabs.sendMessage.bind(chrome.tabs)
        : browser.tabs.sendMessage.bind(browser.tabs);
      // Detect content type for platform-adaptive form labels
      sendMsg(tab.id, { type: "TA_GET_CONTENT_TYPE" }, (response) => {
        if (response && response.contentType && response.contentType !== detectedContentType) {
          detectedContentType = response.contentType;
          renderSubmitTab(); // Re-render with platform-adaptive labels
        }
      });
      sendMsg(tab.id, { type: "TA_GET_HEADLINE" }, (response) => {
        const headlineInput = document.getElementById("sub-headline");
        if (response && response.headline && headlineInput && !headlineInput.value) {
          headlineInput.value = response.headline;
          formState.headline = response.headline;
          headlineInput.placeholder = "The original headline as published";
          debouncedSave();
        } else if (headlineInput) {
          headlineInput.placeholder = "The original headline as published";
        }
      });
      sendMsg(tab.id, { type: "TA_GET_AUTHORS" }, (response) => {
        if (response && response.authors && response.authors.length > 0) {
          detectedAuthors = response.authors.slice(0, 10);
          if (formState.selectedAuthors.length === 0) {
            formState.selectedAuthors = [...detectedAuthors];
            debouncedSave();
            renderSubmitTab();
          }
        }
      });
    }
  } catch (e) {
    const headlineInput = document.getElementById("sub-headline");
    if (headlineInput) headlineInput.placeholder = "The original headline as published";
  }
}

async function doLogin() {
  const username = document.getElementById("login-user").value.trim();
  const password = document.getElementById("login-pass").value;
  const errorEl = document.getElementById("login-error");
  if (!username || !password) {
    errorEl.textContent = "Username and password are required.";
    errorEl.style.display = "block";
    return;
  }
  errorEl.style.display = "none";
  const result = await TA.login(username, password);
  if (!result) {
    errorEl.textContent = "Invalid credentials. Please try again.";
    errorEl.style.display = "block";
    return;
  }
  currentUser = { username: result.username, displayName: result.displayName, id: result.id };
  userAssemblies = await TA.getMyAssemblies();
  renderAuthHeader();
  renderSubmitTab();
  loadCorrections();
}

async function doSubmit() {
  const msgEl = document.getElementById("submit-msg");
  const url = document.getElementById("sub-url").value;
  const originalHeadline = document.getElementById("sub-headline").value.trim();
  const replacementEl = document.getElementById("sub-replacement");
  const replacement = replacementEl ? replacementEl.value.trim() : "";
  const reasoning = document.getElementById("sub-reasoning").value.trim();
  const isAffirm = formState.submitType === "affirmation";

  // Get selected assemblies from chip state
  const selectedOrgs = formState.selectedOrgIds.length > 0 ? [...formState.selectedOrgIds] : [];

  if (selectedOrgs.length === 0) {
    msgEl.className = "submit-msg error";
    msgEl.textContent = "Select at least one assembly.";
    msgEl.style.display = "block";
    return;
  }
  if (!originalHeadline || !reasoning) {
    msgEl.className = "submit-msg error";
    msgEl.textContent = "Headline and reasoning are required.";
    msgEl.style.display = "block";
    return;
  }
  if (!isAffirm && !replacement) {
    msgEl.className = "submit-msg error";
    msgEl.textContent = "A corrected headline is required for corrections.";
    msgEl.style.display = "block";
    return;
  }

  // Disable submit button and show loading
  const btnSubmit = document.getElementById("btn-submit");
  btnSubmit.disabled = true;
  btnSubmit.textContent = "Submitting…";
  msgEl.style.display = "none";

  // Collect inline edits
  const inlineEdits = formState.inlineEdits
    .filter(e => e.original && e.replacement)
    .map(e => ({ original: e.original, replacement: e.replacement, reasoning: e.reasoning || null }));

  // Build evidence from the article URL
  const evidence = [{ url, explanation: "Source article under review" }];

  // Submit the correction/affirmation (multi-assembly via orgIds)
  const result = await TA.submitCorrection({
    submissionType: formState.submitType,
    url,
    originalHeadline,
    replacement: isAffirm ? null : replacement,
    reasoning,
    author: formState.selectedAuthors.length > 0 ? formState.selectedAuthors.join(", ") : null,
    orgIds: selectedOrgs,
    evidence,
    inlineEdits: inlineEdits.length > 0 ? inlineEdits : undefined,
  });

  if (result.error) {
    msgEl.className = "submit-msg error";
    msgEl.textContent = result.error;
    msgEl.style.display = "block";
    btnSubmit.disabled = false;
    btnSubmit.textContent = isAffirm ? "Submit Affirmation" : "Submit Correction";
    return;
  }

  // The submission endpoint returns one result per selected assembly in the
  // same order as orgIds. Preserve that association because vault entries
  // require an explicit assembly even when linked to a submission.
  const submissionIds = result.submissions
    ? result.submissions.map(s => s.id)
    : result.id ? [result.id] : [];
  const submissionTargets = submissionIds.map((id, index) => ({
    id,
    orgId: selectedOrgs[index] || selectedOrgs[0],
  }));

  // Submit vault artifacts — one entry per vault item per submission (each submission maps to one org)
  const vaultPromises = [];

  for (const target of submissionTargets) {
    for (const item of formState.vaultItems.correction) {
      if (item.assertion && item.evidence) {
        vaultPromises.push(TA.submitVault({
          type: "vault",
          submissionId: target.id,
          orgId: target.orgId,
          assertion: item.assertion.trim(),
          evidence: item.evidence.trim(),
        }));
      }
    }

    for (const item of formState.vaultItems.argument) {
      if (item.content) {
        vaultPromises.push(TA.submitVault({
          type: "argument",
          submissionId: target.id,
          orgId: target.orgId,
          content: item.content.trim(),
        }));
      }
    }

    for (const item of formState.vaultItems.belief) {
      if (item.content) {
        vaultPromises.push(TA.submitVault({
          type: "belief",
          submissionId: target.id,
          orgId: target.orgId,
          content: item.content.trim(),
        }));
      }
    }

    for (const item of formState.vaultItems.translation) {
      if (item.original && item.translated) {
        vaultPromises.push(TA.submitVault({
          type: "translation",
          submissionId: target.id,
          orgId: target.orgId,
          original: item.original.trim(),
          translated: item.translated.trim(),
          translationType: item.translationType || "clarity",
        }));
      }
    }
  }

  const vaultResults = vaultPromises.length > 0 ? await Promise.all(vaultPromises) : [];
  const vaultErrors = vaultResults.filter(vaultResult => vaultResult?.error);

  const orgCount = selectedOrgs.length;
  msgEl.className = "submit-msg success";
  msgEl.textContent = isAffirm
    ? `Affirmation submitted to ${orgCount} assembly${orgCount > 1 ? "s" : ""}! It will appear after review.`
    : `Correction submitted to ${orgCount} assembly${orgCount > 1 ? "s" : ""}! It will appear after review.`;
  if (inlineEdits.length > 0) {
    msgEl.textContent += ` ${inlineEdits.length} body correction(s) included.`;
  }
  if (vaultPromises.length > 0) {
    msgEl.textContent += ` ${vaultPromises.length} vault artifact(s) linked.`;
  }
  if (vaultErrors.length > 0) {
    msgEl.className = "submit-msg error";
    msgEl.textContent = `${isAffirm ? "Affirmation" : "Correction"} submitted, but ${vaultErrors.length} vault artifact(s) failed: ${vaultErrors[0].error}`;
  }
  msgEl.style.display = "block";

  btnSubmit.disabled = false;
  btnSubmit.textContent = isAffirm ? "Submit Affirmation" : "Submit Correction";

  // Clear form state and preview
  await clearFormState();
  clearPreviewMessage();

  // Delete server draft for this URL if one exists
  if (cachedDraftsList) {
    const matchingDraft = cachedDraftsList.find(d => d.url === url);
    if (matchingDraft) {
      TA.deleteDraft(matchingDraft.id).catch(() => {});
      cachedDraftsList = cachedDraftsList.filter(d => d.id !== matchingDraft.id);
    }
  }
  pendingUrlDraft = null;
}

// ── Assemblies tab ──
async function renderAssembliesTab() {
  const container = document.getElementById("assemblies-content");

  if (!currentUser) {
    container.innerHTML = `
      <div class="login-panel">
        <h3>Sign in to manage assemblies</h3>
        <input type="text" id="login-user-asm" placeholder="Username or email" autocomplete="username">
        <input type="password" id="login-pass-asm" placeholder="Password" autocomplete="current-password">
        <button class="login-btn" id="btn-login-asm">Sign In</button>
        <div id="login-error-asm" class="login-error" style="display:none"></div>
      </div>
    `;
    document.getElementById("btn-login-asm").addEventListener("click", async () => {
      const username = document.getElementById("login-user-asm").value.trim();
      const password = document.getElementById("login-pass-asm").value;
      const errorEl = document.getElementById("login-error-asm");
      if (!username || !password) { errorEl.textContent = "Username and password required."; errorEl.style.display = "block"; return; }
      const result = await TA.login(username, password);
      if (!result) { errorEl.textContent = "Invalid credentials."; errorEl.style.display = "block"; return; }
      currentUser = { username: result.username, displayName: result.displayName, id: result.id };
      userAssemblies = await TA.getMyAssemblies();
      renderAuthHeader();
      renderAssembliesTab();
    });
    return;
  }

  if (!userAssemblies) {
    userAssemblies = await TA.getMyAssemblies();
  }

  let html = '<div class="assemblies-panel">';

  html += '<h3>Joined Assemblies</h3>';
  if (userAssemblies.joined.length === 0) {
    html += '<div style="font-size:11px; color:#B0A89C; padding:8px 0;">No memberships. <a href="https://trustassembly.org/orgs" target="_blank" style="color:#B8963E">Join on the web</a></div>';
  } else {
    userAssemblies.joined.forEach(org => {
      html += `
        <div class="assembly-row">
          <div><div class="name">${escapeHtml(org.name)}</div><div class="role">Member</div></div>
        </div>
      `;
    });
  }

  html += '<h3 style="margin-top:14px;">Followed Assemblies</h3>';
  if (userAssemblies.followed.length === 0) {
    html += '<div style="font-size:11px; color:#B0A89C; padding:8px 0;">Not following any assemblies yet.</div>';
  } else {
    userAssemblies.followed.forEach(org => {
      html += `
        <div class="assembly-row">
          <div><div class="name">${escapeHtml(org.name)}</div><div class="role">Following</div></div>
          <button class="following" data-unfollow="${escapeHtml(org.id)}">Unfollow</button>
        </div>
      `;
    });
  }

  html += '</div>';
  container.innerHTML = html;

  container.querySelectorAll("[data-unfollow]").forEach(btn => {
    btn.addEventListener("click", async () => {
      await TA.unfollowOrg(btn.dataset.unfollow);
      userAssemblies = await TA.getMyAssemblies();
      renderAssembliesTab();
    });
  });
}

// ── Settings ──
function setupSettings() {
  const storage = (typeof chrome !== "undefined" && chrome.storage?.local)
    || (typeof browser !== "undefined" && browser.storage?.local);
  if (!storage) return;

  storage.get(["showTranslations", "showBadge"], (result) => {
    document.getElementById("toggle-translations").checked = result.showTranslations !== false;
    document.getElementById("toggle-badge").checked = result.showBadge !== false;
  });
  document.getElementById("toggle-translations").addEventListener("change", (e) => {
    storage.set({ showTranslations: e.target.checked });
    notifyContentScript({ showTranslations: e.target.checked });
  });
  document.getElementById("toggle-badge").addEventListener("change", (e) => {
    storage.set({ showBadge: e.target.checked });
    notifyContentScript({ showBadge: e.target.checked });
  });
}

async function notifyContentScript(changedSettings) {
  try {
    const tabs = typeof chrome !== "undefined" && chrome.tabs
      ? await chrome.tabs.query({ active: true, currentWindow: true })
      : await browser.tabs.query({ active: true, currentWindow: true });
    const tab = tabs[0];
    if (tab && tab.id) {
      const message = { type: "TA_SETTINGS_CHANGED", ...changedSettings };
      try {
        chrome.tabs.sendMessage(tab.id, message);
      } catch (e) {
        try { browser.tabs.sendMessage(tab.id, message); } catch (_) {}
      }
    }
  } catch (e) {}
}

// ── Utilities ──

function escapeHtml(str) {
  if (!str) return "";
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

function formatStatus(status) {
  const labels = {
    approved: "✅ Approved", consensus: "🟣 Consensus",
    cross_review: "Cross-Group", pending_review: "Under Review",
    rejected: "Rejected", upheld: "Dispute Upheld"
  };
  return labels[status] || status || "Approved";
}

// ── Live Preview ──
async function sendPreviewMessage(text) {
  try {
    const tabs = typeof chrome !== "undefined" && chrome.tabs
      ? await chrome.tabs.query({ active: true, currentWindow: true })
      : await browser.tabs.query({ active: true, currentWindow: true });
    const tab = tabs[0];
    if (!tab || !tab.id) return;
    const headlineInput = document.getElementById("sub-headline");
    const originalHeadline = headlineInput ? headlineInput.value.trim() : "";
    const sendMsg = (typeof chrome !== "undefined" && chrome.tabs)
      ? chrome.tabs.sendMessage.bind(chrome.tabs)
      : browser.tabs.sendMessage.bind(browser.tabs);
    sendMsg(tab.id, {
      type: "TA_PREVIEW_HEADLINE",
      text: text,
      originalHeadline: originalHeadline,
      isAffirm: formState.submitType === "affirmation"
    }, () => {
      if (typeof chrome !== "undefined" && chrome.runtime?.lastError) {}
    });
  } catch (e) {}
}

let inlinePreviewTimer = null;
function debouncedInlinePreview() {
  clearTimeout(inlinePreviewTimer);
  inlinePreviewTimer = setTimeout(() => sendInlineEditPreviews(), 200);
}

async function sendInlineEditPreviews() {
  try {
    const edits = (formState.inlineEdits || []).filter(e => e.original && e.original.trim());
    const tabs = typeof chrome !== "undefined" && chrome.tabs
      ? await chrome.tabs.query({ active: true, currentWindow: true })
      : await browser.tabs.query({ active: true, currentWindow: true });
    const tab = tabs[0];
    if (!tab || !tab.id) return;
    const sendMsg = (typeof chrome !== "undefined" && chrome.tabs)
      ? chrome.tabs.sendMessage.bind(chrome.tabs)
      : browser.tabs.sendMessage.bind(browser.tabs);
    sendMsg(tab.id, { type: "TA_PREVIEW_INLINE_EDITS", edits }, () => {
      if (typeof chrome !== "undefined" && chrome.runtime?.lastError) {}
    });
  } catch (e) {}
}

async function clearPreviewMessage() {
  try {
    const tabs = typeof chrome !== "undefined" && chrome.tabs
      ? await chrome.tabs.query({ active: true, currentWindow: true })
      : await browser.tabs.query({ active: true, currentWindow: true });
    const tab = tabs[0];
    if (!tab || !tab.id) return;
    const sendMsg = (typeof chrome !== "undefined" && chrome.tabs)
      ? chrome.tabs.sendMessage.bind(chrome.tabs)
      : browser.tabs.sendMessage.bind(browser.tabs);
    sendMsg(tab.id, { type: "TA_CLEAR_PREVIEW" }, () => {
      if (typeof chrome !== "undefined" && chrome.runtime?.lastError) {}
    });
  } catch (e) {}
}
